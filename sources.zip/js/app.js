/**
 * Joomla 3.X template developer boilerplate | 2014
 */

(function($){
    $(document).ready(function(){
        var body = $('.body');

        body.addClass('js-ready');
    });
})(jQuery);